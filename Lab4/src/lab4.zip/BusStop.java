
public class BusStop extends NodeObject {

  int xpos, ypos;
  
  BusStop(String name, int xpos, int ypos) {
    super(name);
    this.xpos = xpos;
    this.ypos = ypos;
  }

}
       
