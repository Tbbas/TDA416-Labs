
import java.util.*;

public class DirectedGraph<E extends Edge> {


	public DirectedGraph(int noOfNodes) {
		;
	}

	public void addEdge(E e) {
		;
	}

	public Iterator<E> shortestPath(int from, int to) {
		return null;
	}
		
	public Iterator<E> minimumSpanningTree() {
		return null;
	}

}
  
